# CRM Properti & Asuransi

APK Android native (Kotlin) untuk agen properti/asuransi. Sudah diisi 7 data prospek contoh (properti & asuransi campur, status beragam: baru kontak, nego, deal, selesai) — otomatis ke-seed saat pertama kali app dibuka (database Room).

## Fitur
- List prospek (nama, no HP, catatan, status, tanggal follow-up berikutnya)
- Tambah / edit / hapus prospek
- Status: Baru Kontak → Nego → Deal → Selesai
- Riwayat interaksi per prospek (multi-baris)
- Data tersimpan lokal (Room/SQLite), tidak perlu internet

## Build via CLI (GitHub Codespaces)

1. Upload/push folder ini ke repo, buka di Codespaces.
2. Kalau `gradlew` belum ada, generate dulu:
   ```
   gradle wrapper --gradle-version 8.7
   ```
3. Build APK debug:
   ```
   ./gradlew assembleDebug
   ```
4. APK ada di:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```
5. Install ke HP via `adb install app-debug.apk`, atau download file APK-nya langsung.

## Struktur
- `data/Prospect.kt` — entity + enum status/jenis
- `data/AppDatabase.kt` — database Room + seed data contoh
- `ui/MainActivity.kt` — list prospek
- `ui/ProspectDetailActivity.kt` — form tambah/edit/hapus
