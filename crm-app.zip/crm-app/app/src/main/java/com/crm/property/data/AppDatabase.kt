package com.crm.property.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Prospect::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun prospectDao(): ProspectDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "crm_properti_db"
                ).addCallback(SeedCallback(scope)).build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class SeedCallback(private val scope: CoroutineScope) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    seedData(database.prospectDao())
                }
            }
        }

        private suspend fun seedData(dao: ProspectDao) {
            val sample = listOf(
                Prospect(
                    name = "Budi Santoso",
                    phone = "0812-3456-7890",
                    type = ProspectType.PROPERTI,
                    notes = "Cari rumah 2 lantai di area Bintaro, budget 1.5M",
                    status = ProspectStatus.NEGO,
                    lastContactDate = "2026-09-10",
                    nextFollowUpDate = "2026-09-17",
                    interactionHistory = "2026-09-05: Kontak awal via WA, kirim brosur||2026-09-10: Survey lokasi bareng, nego harga"
                ),
                Prospect(
                    name = "Siti Rahayu",
                    phone = "0813-2211-9988",
                    type = ProspectType.ASURANSI,
                    notes = "Minat asuransi kesehatan keluarga, 4 anggota",
                    status = ProspectStatus.BARU_KONTAK,
                    lastContactDate = "2026-09-12",
                    nextFollowUpDate = "2026-09-16",
                    interactionHistory = "2026-09-12: Dapat referral dari klien lama, kirim penawaran"
                ),
                Prospect(
                    name = "Ahmad Wijaya",
                    phone = "0857-6677-1234",
                    type = ProspectType.PROPERTI,
                    notes = "Investasi ruko 2 pintu di dekat pasar",
                    status = ProspectStatus.DEAL,
                    lastContactDate = "2026-09-08",
                    nextFollowUpDate = "2026-09-20",
                    interactionHistory = "2026-08-20: Kontak awal||2026-08-30: Nego harga||2026-09-08: Tanda tangan kontrak, deal"
                ),
                Prospect(
                    name = "Dewi Lestari",
                    phone = "0821-9900-4455",
                    type = ProspectType.ASURANSI,
                    notes = "Follow-up perpanjangan polis jiwa tahunan",
                    status = ProspectStatus.SELESAI,
                    lastContactDate = "2026-09-01",
                    nextFollowUpDate = "2027-09-01",
                    interactionHistory = "2026-09-01: Perpanjangan polis berhasil diproses"
                ),
                Prospect(
                    name = "Rudi Hartono",
                    phone = "0878-3344-5566",
                    type = ProspectType.PROPERTI,
                    notes = "Cari apartemen studio dekat kampus buat anak kuliah",
                    status = ProspectStatus.NEGO,
                    lastContactDate = "2026-09-13",
                    nextFollowUpDate = "2026-09-15",
                    interactionHistory = "2026-09-11: Kontak awal via telepon||2026-09-13: Kirim 3 pilihan unit"
                ),
                Prospect(
                    name = "Maya Anggraini",
                    phone = "0896-1122-3344",
                    type = ProspectType.ASURANSI,
                    notes = "Tertarik asuransi pendidikan anak, masih pikir-pikir",
                    status = ProspectStatus.BARU_KONTAK,
                    lastContactDate = "2026-09-14",
                    nextFollowUpDate = "2026-09-18",
                    interactionHistory = "2026-09-14: Kontak awal di pameran, tukar nomor"
                ),
                Prospect(
                    name = "Hendra Gunawan",
                    phone = "0819-8877-2233",
                    type = ProspectType.PROPERTI,
                    notes = "Jual-beli tanah kavling, cek legalitas dulu",
                    status = ProspectStatus.NEGO,
                    lastContactDate = "2026-09-09",
                    nextFollowUpDate = "2026-09-19",
                    interactionHistory = "2026-09-02: Kontak awal||2026-09-09: Diskusi legalitas sertifikat"
                )
            )
            sample.forEach { dao.insert(it) }
        }
    }
}
