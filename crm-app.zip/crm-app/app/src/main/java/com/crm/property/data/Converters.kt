package com.crm.property.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromStatus(status: ProspectStatus): String = status.name

    @TypeConverter
    fun toStatus(value: String): ProspectStatus = ProspectStatus.valueOf(value)

    @TypeConverter
    fun fromType(type: ProspectType): String = type.name

    @TypeConverter
    fun toType(value: String): ProspectType = ProspectType.valueOf(value)
}
