package com.crm.property.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ProspectStatus {
    BARU_KONTAK,
    NEGO,
    DEAL,
    SELESAI
}

enum class ProspectType {
    PROPERTI,
    ASURANSI
}

@Entity(tableName = "prospects")
data class Prospect(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val type: ProspectType,
    val notes: String,
    val status: ProspectStatus,
    val lastContactDate: String,   // format: yyyy-MM-dd
    val nextFollowUpDate: String,  // format: yyyy-MM-dd
    val interactionHistory: String // riwayat singkat, dipisah "||" per entri
)
