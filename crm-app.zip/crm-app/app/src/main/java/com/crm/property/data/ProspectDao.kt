package com.crm.property.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface ProspectDao {

    @Query("SELECT * FROM prospects ORDER BY nextFollowUpDate ASC")
    fun getAll(): LiveData<List<Prospect>>

    @Query("SELECT * FROM prospects WHERE id = :id")
    suspend fun getById(id: Long): Prospect?

    @Insert
    suspend fun insert(prospect: Prospect): Long

    @Update
    suspend fun update(prospect: Prospect)

    @Delete
    suspend fun delete(prospect: Prospect)

    @Query("SELECT COUNT(*) FROM prospects")
    suspend fun count(): Int
}
