package com.crm.property.ui

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.asLiveData
import android.app.Application
import com.crm.property.data.AppDatabase
import com.crm.property.data.Prospect
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.getDatabase(application, viewModelScope).prospectDao()

    val allProspects: LiveData<List<Prospect>> = dao.getAll()

    fun insert(prospect: Prospect) = viewModelScope.launch {
        dao.insert(prospect)
    }

    fun update(prospect: Prospect) = viewModelScope.launch {
        dao.update(prospect)
    }

    fun delete(prospect: Prospect) = viewModelScope.launch {
        dao.delete(prospect)
    }
}
