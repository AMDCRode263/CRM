package com.crm.property.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.crm.property.data.Prospect
import com.crm.property.data.ProspectStatus
import com.crm.property.databinding.ItemProspectBinding

class ProspectAdapter(private val onClick: (Prospect) -> Unit) :
    ListAdapter<Prospect, ProspectAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemProspectBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemProspectBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(prospect: Prospect) {
            binding.textName.text = prospect.name
            binding.textPhone.text = prospect.phone
            binding.textNotes.text = prospect.notes
            binding.textStatus.text = statusLabel(prospect.status)
            binding.textFollowUp.text = "Follow-up: ${prospect.nextFollowUpDate}"
            binding.root.setOnClickListener { onClick(prospect) }
        }

        private fun statusLabel(status: ProspectStatus): String = when (status) {
            ProspectStatus.BARU_KONTAK -> "Baru Kontak"
            ProspectStatus.NEGO -> "Nego"
            ProspectStatus.DEAL -> "Deal"
            ProspectStatus.SELESAI -> "Selesai"
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Prospect>() {
        override fun areItemsTheSame(oldItem: Prospect, newItem: Prospect) =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: Prospect, newItem: Prospect) =
            oldItem == newItem
    }
}
