package com.crm.property.ui

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.crm.property.data.AppDatabase
import com.crm.property.data.Prospect
import com.crm.property.data.ProspectStatus
import com.crm.property.data.ProspectType
import com.crm.property.databinding.ActivityProspectDetailBinding
import kotlinx.coroutines.launch
import java.util.Calendar

class ProspectDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProspectDetailBinding
    private lateinit var viewModel: MainViewModel
    private var currentProspect: Prospect? = null
    private var prospectId: Long = -1L

    private val statusOptions = ProspectStatus.entries.toTypedArray()
    private val typeOptions = ProspectType.entries.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProspectDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        binding.spinnerType.setSimpleItems(typeOptions.map { it.name }.toTypedArray())
        binding.spinnerStatus.setSimpleItems(statusOptions.map { statusLabel(it) }.toTypedArray())

        prospectId = intent.getLongExtra("prospect_id", -1L)

        if (prospectId != -1L) {
            binding.title.text = "Detail Prospek"
            binding.buttonDelete.visibility = android.view.View.VISIBLE
            lifecycleScope.launch {
                val dao = AppDatabase.getDatabase(application, lifecycleScope).prospectDao()
                currentProspect = dao.getById(prospectId)
                currentProspect?.let { populate(it) }
            }
        } else {
            binding.title.text = "Prospek Baru"
            binding.buttonDelete.visibility = android.view.View.GONE
            binding.editNextFollowUp.setText(today())
            binding.editLastContact.setText(today())
        }

        binding.editNextFollowUp.setOnClickListener { pickDate(binding.editNextFollowUp) }
        binding.editLastContact.setOnClickListener { pickDate(binding.editLastContact) }

        binding.buttonSave.setOnClickListener { save() }
        binding.buttonDelete.setOnClickListener { delete() }
    }

    private fun populate(p: Prospect) {
        binding.editName.setText(p.name)
        binding.editPhone.setText(p.phone)
        binding.editNotes.setText(p.notes)
        binding.editLastContact.setText(p.lastContactDate)
        binding.editNextFollowUp.setText(p.nextFollowUpDate)
        binding.editHistory.setText(p.interactionHistory.replace("||", "\n"))
        binding.spinnerType.setText(p.type.name, false)
        binding.spinnerStatus.setText(statusLabel(p.status), false)
    }

    private fun statusLabel(status: ProspectStatus): String = when (status) {
        ProspectStatus.BARU_KONTAK -> "Baru Kontak"
        ProspectStatus.NEGO -> "Nego"
        ProspectStatus.DEAL -> "Deal"
        ProspectStatus.SELESAI -> "Selesai"
    }

    private fun pickDate(target: android.widget.EditText) {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            target.setText(String.format("%04d-%02d-%02d", y, m + 1, d))
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun today(): String {
        val cal = Calendar.getInstance()
        return String.format(
            "%04d-%02d-%02d",
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    private fun save() {
        val name = binding.editName.text.toString().trim()
        val phone = binding.editPhone.text.toString().trim()
        if (name.isEmpty() || phone.isEmpty()) {
            binding.editName.error = if (name.isEmpty()) "Wajib diisi" else null
            binding.editPhone.error = if (phone.isEmpty()) "Wajib diisi" else null
            return
        }

        val type = typeOptions.firstOrNull { it.name == binding.spinnerType.text.toString() }
            ?: ProspectType.PROPERTI
        val status = statusOptions.firstOrNull { statusLabel(it) == binding.spinnerStatus.text.toString() }
            ?: ProspectStatus.BARU_KONTAK

        val history = binding.editHistory.text.toString().trim()
            .split("\n").filter { it.isNotBlank() }.joinToString("||")

        val prospect = Prospect(
            id = currentProspect?.id ?: 0,
            name = name,
            phone = phone,
            type = type,
            notes = binding.editNotes.text.toString().trim(),
            status = status,
            lastContactDate = binding.editLastContact.text.toString().trim(),
            nextFollowUpDate = binding.editNextFollowUp.text.toString().trim(),
            interactionHistory = history
        )

        if (currentProspect == null) {
            viewModel.insert(prospect)
        } else {
            viewModel.update(prospect)
        }
        finish()
    }

    private fun delete() {
        currentProspect?.let {
            viewModel.delete(it)
            finish()
        }
    }
}
