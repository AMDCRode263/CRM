# CRM Pro — Properti & Asuransi

Versi lengkap sesuai spek: Dashboard, Leads, Customers (Customer 360°), Sales Pipeline (kanban per stage),
Tasks, Products/Services, Communication (log interaksi terpusat), Reports & Analytics, AI Sales Assistant
(rule-based lokal, tanpa API eksternal), dan Settings — semua fungsi CRUD & logic beneran jalan, bukan mockup visual.

## Yang real vs yang mock
- **Real & fungsional**: semua CRUD (Lead/Customer/Deal/Task/Product), convert Lead→Customer, pipeline per stage,
  quotation builder dari katalog produk, dashboard stats dihitung dari database asli, reports dihitung real-time,
  reset data.
- **Mock/local logic** (sesuai instruksi kamu — karena tidak ada API eksternal): AI Sales Assistant & forecasting
  pakai rule-based lokal (bukan LLM), Communication dianggap satu log lokal (bukan integrasi WhatsApp/Email asli),
  Team masih single-user (belum multi-user beneran), Cloud sync belum aktif (struktur data sudah siap untuk itu nanti).

## Build (GitHub Codespaces)

```bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
export ANDROID_HOME=$HOME/android-sdk
echo "sdk.dir=$ANDROID_HOME" > local.properties
./gradlew assembleDebug
```

APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

Kalau muncul error compile, kirim pesan errornya — biasanya cuma 1-2 baris kode yang perlu diperbaiki (seperti sebelumnya).
