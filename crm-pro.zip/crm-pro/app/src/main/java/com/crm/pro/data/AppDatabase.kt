package com.crm.pro.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Lead::class, Customer::class, Deal::class, Task::class, Product::class, Interaction::class, Quotation::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun leadDao(): LeadDao
    abstract fun customerDao(): CustomerDao
    abstract fun dealDao(): DealDao
    abstract fun taskDao(): TaskDao
    abstract fun productDao(): ProductDao
    abstract fun interactionDao(): InteractionDao
    abstract fun quotationDao(): QuotationDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, "crm_pro_db"
                ).addCallback(SeedCallback(scope)).build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class SeedCallback(private val scope: CoroutineScope) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) { seed(database) }
            }
        }

        private suspend fun seed(db: AppDatabase) {
            // Products
            val products = listOf(
                Product(name = "Paket Asuransi Kesehatan Keluarga", price = 2500000.0, description = "Perlindungan kesehatan 4 anggota keluarga, 1 tahun"),
                Product(name = "Paket Asuransi Jiwa Premium", price = 4000000.0, description = "Perlindungan jiwa dengan manfaat investasi"),
                Product(name = "Jasa Konsultasi Properti", price = 500000.0, description = "Konsultasi & survey lokasi properti"),
                Product(name = "Jasa Legalitas Sertifikat", price = 1500000.0, description = "Pengurusan legalitas dan balik nama sertifikat")
            )
            val productIds = products.map { db.productDao().insert(it) }

            // Leads
            val leads = listOf(
                Lead(name = "Maya Anggraini", phone = "0896-1122-3344", email = "maya.a@email.com", source = LeadSource.PAMERAN, status = LeadStatus.NEW, score = 40, notes = "Tertarik asuransi pendidikan anak, masih pikir-pikir", createdDate = "2026-09-14"),
                Lead(name = "Fajar Nugroho", phone = "0815-2233-8899", email = "fajar.n@email.com", source = LeadSource.WEBSITE, status = LeadStatus.CONTACTED, score = 65, notes = "Isi form web, minat rumah subsidi", createdDate = "2026-09-15"),
                Lead(name = "Rina Kusuma", phone = "0822-4455-6677", email = "rina.k@email.com", source = LeadSource.REFERRAL, status = LeadStatus.QUALIFIED, score = 80, notes = "Referral dari klien lama, siap survey", createdDate = "2026-09-11"),
                Lead(name = "Yusuf Pratama", phone = "0838-9900-1122", email = "yusuf.p@email.com", source = LeadSource.SOCIAL_MEDIA, status = LeadStatus.NEW, score = 30, notes = "Komen di Instagram, belum respon DM", createdDate = "2026-09-16")
            )
            leads.forEach { db.leadDao().insert(it) }

            // Customers
            val custBudi = Customer(name = "Budi Santoso", phone = "0812-3456-7890", email = "budi.s@email.com", company = "-", notes = "Cari rumah 2 lantai di area Bintaro, budget 1.5M", createdDate = "2026-09-05")
            val custSiti = Customer(name = "Siti Rahayu", phone = "0813-2211-9988", email = "siti.r@email.com", company = "-", notes = "Asuransi kesehatan keluarga, 4 anggota", createdDate = "2026-09-12")
            val custAhmad = Customer(name = "Ahmad Wijaya", phone = "0857-6677-1234", email = "ahmad.w@email.com", company = "CV Wijaya Jaya", notes = "Investasi ruko 2 pintu di dekat pasar", createdDate = "2026-08-20")
            val custDewi = Customer(name = "Dewi Lestari", phone = "0821-9900-4455", email = "dewi.l@email.com", company = "-", notes = "Perpanjangan polis jiwa tahunan", createdDate = "2026-09-01")

            val budiId = db.customerDao().insert(custBudi)
            val sitiId = db.customerDao().insert(custSiti)
            val ahmadId = db.customerDao().insert(custAhmad)
            val dewiId = db.customerDao().insert(custDewi)

            // Deals
            val dealBudi = Deal(title = "Rumah 2 Lantai Bintaro - Budi Santoso", customerId = budiId, value = 1500000000.0, stage = DealStage.NEGOTIATION, expectedCloseDate = "2026-09-25", notes = "Nego harga, tinggal DP", createdDate = "2026-09-10")
            val dealSiti = Deal(title = "Asuransi Kesehatan Keluarga - Siti Rahayu", customerId = sitiId, value = 2500000.0, stage = DealStage.PROPOSAL, expectedCloseDate = "2026-09-20", notes = "Kirim penawaran, tunggu konfirmasi", createdDate = "2026-09-12")
            val dealAhmad = Deal(title = "Ruko 2 Pintu - Ahmad Wijaya", customerId = ahmadId, value = 850000000.0, stage = DealStage.WON, expectedCloseDate = "2026-09-08", notes = "Deal, kontrak sudah ditandatangani", createdDate = "2026-08-20")
            val dealDewi = Deal(title = "Perpanjangan Polis Jiwa - Dewi Lestari", customerId = dewiId, value = 4000000.0, stage = DealStage.WON, expectedCloseDate = "2026-09-01", notes = "Perpanjangan berhasil diproses", createdDate = "2026-09-01")

            val dealBudiId = db.dealDao().insert(dealBudi)
            db.dealDao().insert(dealSiti)
            db.dealDao().insert(dealAhmad)
            db.dealDao().insert(dealDewi)

            // Tasks
            val tasks = listOf(
                Task(title = "Follow-up nego harga rumah", relatedType = RelatedType.CUSTOMER, relatedId = budiId, relatedName = custBudi.name, dueDate = "2026-09-19", done = false, notes = "Telepon jam 10 pagi"),
                Task(title = "Kirim ulang penawaran asuransi", relatedType = RelatedType.CUSTOMER, relatedId = sitiId, relatedName = custSiti.name, dueDate = "2026-09-20", done = false, notes = "Lewat WhatsApp"),
                Task(title = "Hubungi lead pameran", relatedType = RelatedType.LEAD, relatedId = leads[0].id, relatedName = leads[0].name, dueDate = "2026-09-18", done = false, notes = "Baru dapat kontak, perkenalan"),
                Task(title = "Survey lokasi ruko", relatedType = RelatedType.CUSTOMER, relatedId = ahmadId, relatedName = custAhmad.name, dueDate = "2026-09-10", done = true, notes = "Sudah selesai, deal")
            )
            tasks.forEach { db.taskDao().insert(it) }

            // Interactions (communication log / timeline)
            val interactions = listOf(
                Interaction(relatedType = RelatedType.CUSTOMER, relatedId = budiId, relatedName = custBudi.name, type = InteractionType.WHATSAPP, note = "Kirim brosur rumah", date = "2026-09-05"),
                Interaction(relatedType = RelatedType.CUSTOMER, relatedId = budiId, relatedName = custBudi.name, type = InteractionType.MEETING, note = "Survey lokasi bareng, nego harga", date = "2026-09-10"),
                Interaction(relatedType = RelatedType.CUSTOMER, relatedId = sitiId, relatedName = custSiti.name, type = InteractionType.CALL, note = "Diskusi kebutuhan asuransi keluarga", date = "2026-09-12"),
                Interaction(relatedType = RelatedType.CUSTOMER, relatedId = ahmadId, relatedName = custAhmad.name, type = InteractionType.EMAIL, note = "Kirim kontrak final", date = "2026-09-08"),
                Interaction(relatedType = RelatedType.LEAD, relatedId = leads[2].id, relatedName = leads[2].name, type = InteractionType.CALL, note = "Follow-up referral, siap survey minggu depan", date = "2026-09-11")
            )
            interactions.forEach { db.interactionDao().insert(it) }

            // Quotation contoh
            val quotationItems = "Paket Asuransi Kesehatan Keluarga x1 (Rp2.500.000)"
            db.quotationDao().insert(
                Quotation(dealId = dealBudiId, dealTitle = dealSiti.title, itemsSummary = quotationItems, total = 2500000.0, createdDate = "2026-09-12")
            )
        }
    }
}
