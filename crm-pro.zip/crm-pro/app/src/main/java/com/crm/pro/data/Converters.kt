package com.crm.pro.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter fun fromLeadStatus(v: LeadStatus) = v.name
    @TypeConverter fun toLeadStatus(v: String) = LeadStatus.valueOf(v)

    @TypeConverter fun fromLeadSource(v: LeadSource) = v.name
    @TypeConverter fun toLeadSource(v: String) = LeadSource.valueOf(v)

    @TypeConverter fun fromDealStage(v: DealStage) = v.name
    @TypeConverter fun toDealStage(v: String) = DealStage.valueOf(v)

    @TypeConverter fun fromInteractionType(v: InteractionType) = v.name
    @TypeConverter fun toInteractionType(v: String) = InteractionType.valueOf(v)

    @TypeConverter fun fromRelatedType(v: RelatedType?) = v?.name
    @TypeConverter fun toRelatedType(v: String?) = v?.let { RelatedType.valueOf(it) }
}
