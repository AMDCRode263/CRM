package com.crm.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val email: String,
    val company: String,
    val notes: String,
    val createdDate: String,
    val convertedFromLeadId: Long? = null
)
