package com.crm.pro.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface LeadDao {
    @Query("SELECT * FROM leads ORDER BY score DESC")
    fun getAll(): LiveData<List<Lead>>
    @Query("SELECT * FROM leads WHERE id = :id")
    suspend fun getById(id: Long): Lead?
    @Insert suspend fun insert(item: Lead): Long
    @Update suspend fun update(item: Lead)
    @Delete suspend fun delete(item: Lead)
    @Query("SELECT COUNT(*) FROM leads") suspend fun count(): Int
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name ASC")
    fun getAll(): LiveData<List<Customer>>
    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getById(id: Long): Customer?
    @Insert suspend fun insert(item: Customer): Long
    @Update suspend fun update(item: Customer)
    @Delete suspend fun delete(item: Customer)
    @Query("SELECT COUNT(*) FROM customers") suspend fun count(): Int
}

@Dao
interface DealDao {
    @Query("SELECT * FROM deals ORDER BY createdDate DESC")
    fun getAll(): LiveData<List<Deal>>
    @Query("SELECT * FROM deals WHERE id = :id")
    suspend fun getById(id: Long): Deal?
    @Insert suspend fun insert(item: Deal): Long
    @Update suspend fun update(item: Deal)
    @Delete suspend fun delete(item: Deal)
    @Query("SELECT COUNT(*) FROM deals WHERE stage NOT IN ('WON','LOST')") suspend fun countActive(): Int
    @Query("SELECT COALESCE(SUM(value),0) FROM deals WHERE stage = 'WON'") suspend fun totalRevenue(): Double
    @Query("SELECT COUNT(*) FROM deals") suspend fun countAll(): Int
    @Query("SELECT COUNT(*) FROM deals WHERE stage = 'WON'") suspend fun countWon(): Int
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY done ASC, dueDate ASC")
    fun getAll(): LiveData<List<Task>>
    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getById(id: Long): Task?
    @Insert suspend fun insert(item: Task): Long
    @Update suspend fun update(item: Task)
    @Delete suspend fun delete(item: Task)
    @Query("SELECT * FROM tasks WHERE done = 0 AND dueDate <= :date")
    suspend fun getOverdueOrToday(date: String): List<Task>
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAll(): LiveData<List<Product>>
    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getById(id: Long): Product?
    @Insert suspend fun insert(item: Product): Long
    @Update suspend fun update(item: Product)
    @Delete suspend fun delete(item: Product)
}

@Dao
interface InteractionDao {
    @Query("SELECT * FROM interactions ORDER BY date DESC, id DESC")
    fun getAll(): LiveData<List<Interaction>>
    @Query("SELECT * FROM interactions WHERE relatedType = :type AND relatedId = :id ORDER BY date DESC, id DESC")
    fun getForRelated(type: RelatedType, id: Long): LiveData<List<Interaction>>
    @Insert suspend fun insert(item: Interaction): Long
    @Delete suspend fun delete(item: Interaction)
}

@Dao
interface QuotationDao {
    @Query("SELECT * FROM quotations ORDER BY createdDate DESC")
    fun getAll(): LiveData<List<Quotation>>
    @Query("SELECT * FROM quotations WHERE dealId = :dealId ORDER BY createdDate DESC")
    fun getForDeal(dealId: Long): LiveData<List<Quotation>>
    @Insert suspend fun insert(item: Quotation): Long
    @Delete suspend fun delete(item: Quotation)
}
