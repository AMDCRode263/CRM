package com.crm.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "deals")
data class Deal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val customerId: Long,
    val value: Double,
    val stage: DealStage,
    val expectedCloseDate: String,
    val notes: String,
    val createdDate: String
)
