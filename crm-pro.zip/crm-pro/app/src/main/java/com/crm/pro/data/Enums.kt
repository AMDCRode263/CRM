package com.crm.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class LeadStatus { NEW, CONTACTED, QUALIFIED, CONVERTED, LOST }
enum class LeadSource { WEBSITE, REFERRAL, PAMERAN, SOCIAL_MEDIA, WALK_IN, LAINNYA }
enum class DealStage { LEAD, QUALIFIED, PROPOSAL, NEGOTIATION, WON, LOST }
enum class InteractionType { CALL, WHATSAPP, EMAIL, MEETING, NOTE }
enum class RelatedType { LEAD, CUSTOMER, DEAL }

@Entity(tableName = "leads")
data class Lead(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val email: String,
    val source: LeadSource,
    val status: LeadStatus,
    val score: Int, // 0-100, lead scoring
    val notes: String,
    val createdDate: String
)
