package com.crm.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "interactions")
data class Interaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val relatedType: RelatedType,
    val relatedId: Long,
    val relatedName: String,
    val type: InteractionType,
    val note: String,
    val date: String
)
