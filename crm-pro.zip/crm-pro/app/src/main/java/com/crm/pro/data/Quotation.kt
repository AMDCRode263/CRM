package com.crm.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quotations")
data class Quotation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dealId: Long,
    val dealTitle: String,
    val itemsSummary: String, // "Produk A x2 (Rp200.000)||Produk B x1 (Rp150.000)"
    val total: Double,
    val createdDate: String
)
