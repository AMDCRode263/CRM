package com.crm.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val relatedType: RelatedType?,
    val relatedId: Long?,
    val relatedName: String, // denormalized display name, e.g. "Budi Santoso"
    val dueDate: String,
    val done: Boolean,
    val notes: String
)
