package com.crm.pro.ui

import android.app.Application
import androidx.lifecycle.*
import com.crm.pro.data.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import java.text.SimpleDateFormat
import java.util.*

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application, viewModelScope)
    private val leadDao = db.leadDao()
    private val customerDao = db.customerDao()
    private val dealDao = db.dealDao()
    private val taskDao = db.taskDao()
    private val productDao = db.productDao()
    private val interactionDao = db.interactionDao()
    private val quotationDao = db.quotationDao()

    val leads: LiveData<List<Lead>> = leadDao.getAll()
    val customers: LiveData<List<Customer>> = customerDao.getAll()
    val deals: LiveData<List<Deal>> = dealDao.getAll()
    val tasks: LiveData<List<Task>> = taskDao.getAll()
    val products: LiveData<List<Product>> = productDao.getAll()
    val interactions: LiveData<List<Interaction>> = interactionDao.getAll()
    val quotations: LiveData<List<Quotation>> = quotationDao.getAll()

    // ---- Leads ----
    fun insertLead(l: Lead, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = leadDao.insert(l); onDone(id)
    }
    fun updateLead(l: Lead) = viewModelScope.launch { leadDao.update(l) }
    fun deleteLead(l: Lead) = viewModelScope.launch { leadDao.delete(l) }
    suspend fun getLead(id: Long) = leadDao.getById(id)

    /** Convert a Lead into a Customer (core CRM workflow). */
    fun convertLeadToCustomer(lead: Lead, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val customer = Customer(
            name = lead.name, phone = lead.phone, email = lead.email,
            company = "-", notes = lead.notes, createdDate = today(), convertedFromLeadId = lead.id
        )
        val newId = customerDao.insert(customer)
        leadDao.update(lead.copy(status = LeadStatus.CONVERTED))
        logInteraction(RelatedType.CUSTOMER, newId, customer.name, InteractionType.NOTE, "Dikonversi dari lead")
        onDone(newId)
    }

    // ---- Customers ----
    fun insertCustomer(c: Customer, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = customerDao.insert(c); onDone(id)
    }
    fun updateCustomer(c: Customer) = viewModelScope.launch { customerDao.update(c) }
    fun deleteCustomer(c: Customer) = viewModelScope.launch { customerDao.delete(c) }
    suspend fun getCustomer(id: Long) = customerDao.getById(id)
    fun interactionsFor(type: RelatedType, id: Long): LiveData<List<Interaction>> =
        interactionDao.getForRelated(type, id)

    // ---- Deals ----
    fun insertDeal(d: Deal, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = dealDao.insert(d); onDone(id)
    }
    fun updateDeal(d: Deal) = viewModelScope.launch { dealDao.update(d) }
    fun deleteDeal(d: Deal) = viewModelScope.launch { dealDao.delete(d) }
    suspend fun getDeal(id: Long) = dealDao.getById(id)
    fun quotationsForDeal(dealId: Long): LiveData<List<Quotation>> = quotationDao.getForDeal(dealId)

    // ---- Tasks ----
    fun insertTask(t: Task, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = taskDao.insert(t); onDone(id)
    }
    fun updateTask(t: Task) = viewModelScope.launch { taskDao.update(t) }
    fun deleteTask(t: Task) = viewModelScope.launch { taskDao.delete(t) }
    suspend fun getTask(id: Long) = taskDao.getById(id)

    // ---- Products ----
    fun insertProduct(p: Product, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = productDao.insert(p); onDone(id)
    }
    fun updateProduct(p: Product) = viewModelScope.launch { productDao.update(p) }
    fun deleteProduct(p: Product) = viewModelScope.launch { productDao.delete(p) }
    suspend fun getProduct(id: Long) = productDao.getById(id)

    // ---- Interactions / Communication log ----
    fun logInteraction(type: RelatedType, id: Long, name: String, kind: InteractionType, note: String) =
        viewModelScope.launch {
            interactionDao.insert(Interaction(relatedType = type, relatedId = id, relatedName = name, type = kind, note = note, date = today()))
        }

    // ---- Quotation ----
    fun createQuotation(q: Quotation) = viewModelScope.launch { quotationDao.insert(q) }

    // ---- Dashboard stats (computed, real numbers from DB) ----
    data class DashboardStats(
        val totalLeads: Int, val totalCustomers: Int, val activeDeals: Int,
        val revenue: Double, val conversionRate: Int
    )

    suspend fun loadDashboardStats(): DashboardStats {
        val totalLeads = leadDao.count()
        val totalCustomers = customerDao.count()
        val activeDeals = dealDao.countActive()
        val revenue = dealDao.totalRevenue()
        val totalDeals = dealDao.countAll()
        val won = dealDao.countWon()
        val conversion = if (totalDeals > 0) (won * 100 / totalDeals) else 0
        return DashboardStats(totalLeads, totalCustomers, activeDeals, revenue, conversion)
    }

    // ---- AI Sales Assistant (mock/local rule-based logic — no external API) ----
    suspend fun generateAiInsights(): List<String> = withContextIO {
        val insights = mutableListOf<String>()
        val allLeads = leadDao.getAll().value ?: emptyList()
        val allDeals = dealDao.getAll().value ?: emptyList()
        val overdueTasks = taskDao.getOverdueOrToday(today())

        // Rule 1: leads dengan score tinggi tapi belum dikontak
        val hotLeads = allLeads.filter { it.score >= 70 && it.status == LeadStatus.NEW }
        if (hotLeads.isNotEmpty()) {
            insights.add("🔥 ${hotLeads.size} lead skor tinggi belum di-follow-up: ${hotLeads.joinToString { it.name }}. Prioritaskan hubungi hari ini.")
        }

        // Rule 2: deal lama di stage yang sama (stuck deal)
        val stuckDeals = allDeals.filter { it.stage == DealStage.NEGOTIATION || it.stage == DealStage.PROPOSAL }
        if (stuckDeals.isNotEmpty()) {
            insights.add("⚠️ ${stuckDeals.size} deal masih di tahap nego/proposal: ${stuckDeals.joinToString { it.title }}. Pertimbangkan follow-up lebih intens.")
        }

        // Rule 3: overdue tasks
        if (overdueTasks.isNotEmpty()) {
            insights.add("📌 ${overdueTasks.size} tugas jatuh tempo hari ini/lewat: ${overdueTasks.joinToString { it.title }}.")
        }

        // Rule 4: forecast sederhana — proyeksi revenue dari deal aktif (bobot berdasar stage)
        val forecast = allDeals.filter { it.stage != DealStage.LOST && it.stage != DealStage.WON }.sumOf {
            val weight = when (it.stage) {
                DealStage.LEAD -> 0.1
                DealStage.QUALIFIED -> 0.3
                DealStage.PROPOSAL -> 0.5
                DealStage.NEGOTIATION -> 0.7
                else -> 0.0
            }
            it.value * weight
        }
        insights.add("📊 Proyeksi revenue dari deal aktif (weighted forecast): ${formatRupiah(forecast)}.")

        if (insights.isEmpty()) insights.add("Semua terlihat aman. Belum ada prioritas mendesak.")
        insights
    }

    private suspend fun <T> withContextIO(block: suspend () -> T): T =
        kotlinx.coroutines.withContext(Dispatchers.IO) { block() }

    companion object {
        fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        fun formatRupiah(value: Double): String {
            val formatted = String.format(Locale("in", "ID"), "%,.0f", value)
            return "Rp$formatted"
        }
    }
}
