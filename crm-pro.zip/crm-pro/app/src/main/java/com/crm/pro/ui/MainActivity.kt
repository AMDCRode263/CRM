package com.crm.pro.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.fragment.app.Fragment
import com.crm.pro.databinding.ActivityMainBinding
import com.crm.pro.ui.ai.AiAssistantFragment
import com.crm.pro.ui.communication.CommunicationFragment
import com.crm.pro.ui.customers.CustomersFragment
import com.crm.pro.ui.dashboard.DashboardFragment
import com.crm.pro.ui.deals.DealsFragment
import com.crm.pro.ui.leads.LeadsFragment
import com.crm.pro.ui.products.ProductsFragment
import com.crm.pro.ui.reports.ReportsFragment
import com.crm.pro.ui.settings.SettingsFragment
import com.crm.pro.ui.tasks.TasksFragment
import com.crm.pro.R

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val toggle = ActionBarDrawerToggle(
            this, binding.drawerLayout, binding.toolbar,
            androidx.appcompat.R.string.abc_action_bar_up_description,
            androidx.appcompat.R.string.abc_action_bar_up_description
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        if (savedInstanceState == null) {
            openFragment(DashboardFragment(), "Dashboard")
            binding.navigationView.setCheckedItem(R.id.nav_dashboard)
        }

        binding.navigationView.setNavigationItemSelectedListener { item ->
            val (fragment, label) = when (item.itemId) {
                R.id.nav_dashboard -> DashboardFragment() to "Dashboard"
                R.id.nav_leads -> LeadsFragment() to "Leads"
                R.id.nav_customers -> CustomersFragment() to "Customers"
                R.id.nav_deals -> DealsFragment() to "Sales Pipeline"
                R.id.nav_tasks -> TasksFragment() to "Tasks"
                R.id.nav_products -> ProductsFragment() to "Products / Services"
                R.id.nav_communication -> CommunicationFragment() to "Communication"
                R.id.nav_reports -> ReportsFragment() to "Reports & Analytics"
                R.id.nav_ai -> AiAssistantFragment() to "AI Sales Assistant"
                R.id.nav_settings -> SettingsFragment() to "Settings"
                else -> DashboardFragment() to "Dashboard"
            }
            openFragment(fragment, label)
            binding.drawerLayout.closeDrawers()
            true
        }
    }

    private fun openFragment(fragment: Fragment, title: String) {
        supportFragmentManager.beginTransaction()
            .replace(binding.fragmentContainer.id, fragment)
            .commit()
        supportActionBar?.title = title
    }
}
