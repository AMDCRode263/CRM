package com.crm.pro.ui.ai

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.crm.pro.databinding.FragmentListBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.common.SimpleLine
import com.crm.pro.ui.common.SimpleLineAdapter
import kotlinx.coroutines.launch

/**
 * AI Sales Assistant & Forecasting — no external LLM/API wired up, so this runs on local
 * rule-based logic per the abstraction-layer/mock-fallback requirement. Swappable later
 * for a real API-backed implementation behind the same generateAiInsights() call.
 */
class AiAssistantFragment : Fragment() {

    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by viewModels({ requireActivity() })
    private lateinit var adapter: SimpleLineAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = SimpleLineAdapter(emptyList())
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        refresh()
        viewModel.leads.observe(viewLifecycleOwner) { refresh() }
        viewModel.deals.observe(viewLifecycleOwner) { refresh() }
        viewModel.tasks.observe(viewLifecycleOwner) { refresh() }
    }

    private fun refresh() {
        viewLifecycleOwner.lifecycleScope.launch {
            val insights = viewModel.generateAiInsights()
            binding.emptyView.visibility = View.GONE
            adapter.submit(insights.map { SimpleLine(title = it, subtitle = "") })
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
