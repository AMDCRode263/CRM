package com.crm.pro.ui.common

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/**
 * Lightweight line/area chart, no external charting library needed
 * (keeps the build offline-friendly — no extra Maven repo required).
 */
class LineChartView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var values: List<Float> = emptyList()
    private var labels: List<String> = emptyList()

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3B82F6")
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#333B82F6")
        style = Paint.Style.FILL
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3B82F6")
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#94A3B8")
        textSize = 26f
        textAlign = Paint.Align.CENTER
    }

    fun setData(newValues: List<Float>, newLabels: List<String>) {
        values = newValues
        labels = newLabels
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (values.isEmpty()) return

        val paddingTop = 20f
        val paddingBottom = 50f
        val paddingSide = 20f
        val chartWidth = width - paddingSide * 2
        val chartHeight = height - paddingTop - paddingBottom

        val maxVal = (values.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val minVal = 0f
        val stepX = if (values.size > 1) chartWidth / (values.size - 1) else 0f

        fun xFor(i: Int) = paddingSide + stepX * i
        fun yFor(v: Float) = paddingTop + chartHeight - ((v - minVal) / (maxVal - minVal)) * chartHeight

        val linePath = Path()
        val fillPath = Path()

        values.forEachIndexed { i, v ->
            val x = xFor(i)
            val y = yFor(v)
            if (i == 0) {
                linePath.moveTo(x, y)
                fillPath.moveTo(x, paddingTop + chartHeight)
                fillPath.lineTo(x, y)
            } else {
                linePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(xFor(values.size - 1), paddingTop + chartHeight)
        fillPath.close()

        canvas.drawPath(fillPath, fillPaint)
        canvas.drawPath(linePath, linePaint)

        values.forEachIndexed { i, v ->
            canvas.drawCircle(xFor(i), yFor(v), 8f, dotPaint)
        }

        labels.forEachIndexed { i, label ->
            if (i < values.size) {
                canvas.drawText(label, xFor(i), height - 10f, labelPaint)
            }
        }
    }
}
