package com.crm.pro.ui.common

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.crm.pro.databinding.ItemSimpleLineBinding

data class SimpleLine(val title: String, val subtitle: String, val onClick: (() -> Unit)? = null)

class SimpleLineAdapter(private var items: List<SimpleLine>) :
    RecyclerView.Adapter<SimpleLineAdapter.VH>() {

    fun submit(newItems: List<SimpleLine>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemSimpleLineBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])
    override fun getItemCount() = items.size

    class VH(private val binding: ItemSimpleLineBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: SimpleLine) {
            binding.lineTitle.text = item.title
            binding.lineSubtitle.text = item.subtitle
            binding.root.setOnClickListener { item.onClick?.invoke() }
        }
    }
}
