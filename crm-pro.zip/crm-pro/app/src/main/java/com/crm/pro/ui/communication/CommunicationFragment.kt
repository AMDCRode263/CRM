package com.crm.pro.ui.communication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.crm.pro.databinding.FragmentListBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.common.SimpleLine
import com.crm.pro.ui.common.SimpleLineAdapter

/**
 * Omnichannel Communication log — unifies all interactions (call/whatsapp/email/meeting/note)
 * across Leads/Customers/Deals into a single chronological feed. Mocked "channel" concept:
 * no real external messaging API, all logging happens locally (as allowed by the spec's
 * mock/local-fallback requirement for channels without an API).
 */
class CommunicationFragment : Fragment() {

    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by viewModels({ requireActivity() })
    private lateinit var adapter: SimpleLineAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = SimpleLineAdapter(emptyList())
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        viewModel.interactions.observe(viewLifecycleOwner) { list ->
            binding.emptyView.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            adapter.submit(list.map {
                SimpleLine(
                    title = "[${it.type.name}] ${it.relatedName} (${it.relatedType.name})",
                    subtitle = "${it.date} — ${it.note}"
                )
            })
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
