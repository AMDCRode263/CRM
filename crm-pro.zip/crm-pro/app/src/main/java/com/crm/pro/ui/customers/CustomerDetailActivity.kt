package com.crm.pro.ui.customers

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.crm.pro.data.Customer
import com.crm.pro.data.InteractionType
import com.crm.pro.data.RelatedType
import com.crm.pro.databinding.ActivityCustomerDetailBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.AppViewModel.Companion.formatRupiah
import com.crm.pro.ui.common.SimpleLine
import com.crm.pro.ui.common.SimpleLineAdapter
import kotlinx.coroutines.launch

class CustomerDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCustomerDetailBinding
    private val viewModel: AppViewModel by viewModels()
    private var currentCustomer: Customer? = null
    private var customerId: Long = -1L

    private lateinit var dealsAdapter: SimpleLineAdapter
    private lateinit var timelineAdapter: SimpleLineAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomerDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dealsAdapter = SimpleLineAdapter(emptyList())
        binding.recyclerDeals.layoutManager = LinearLayoutManager(this)
        binding.recyclerDeals.adapter = dealsAdapter

        timelineAdapter = SimpleLineAdapter(emptyList())
        binding.recyclerTimeline.layoutManager = LinearLayoutManager(this)
        binding.recyclerTimeline.adapter = timelineAdapter

        customerId = intent.getLongExtra("customer_id", -1L)

        if (customerId != -1L) {
            binding.title.text = "Customer 360°"
            binding.buttonDelete.visibility = android.view.View.VISIBLE
            binding.section360.visibility = android.view.View.VISIBLE

            lifecycleScope.launch {
                currentCustomer = viewModel.getCustomer(customerId)
                currentCustomer?.let { populate(it) }
            }

            viewModel.deals.observe(this) { allDeals ->
                val related = allDeals.filter { it.customerId == customerId }
                dealsAdapter.submit(related.map {
                    SimpleLine(title = it.title, subtitle = "${it.stage.name} • ${formatRupiah(it.value)}")
                })
            }

            viewModel.interactionsFor(RelatedType.CUSTOMER, customerId).observe(this) { list ->
                timelineAdapter.submit(list.map {
                    SimpleLine(title = "${it.type.name} — ${it.date}", subtitle = it.note)
                })
            }

            binding.buttonAddInteraction.setOnClickListener {
                val note = binding.editNewInteraction.text.toString().trim()
                if (note.isNotEmpty()) {
                    viewModel.logInteraction(RelatedType.CUSTOMER, customerId, currentCustomer?.name ?: "", InteractionType.NOTE, note)
                    binding.editNewInteraction.setText("")
                }
            }
        } else {
            binding.title.text = "Customer Baru"
        }

        binding.buttonSave.setOnClickListener { save() }
        binding.buttonDelete.setOnClickListener { delete() }
    }

    private fun populate(c: Customer) {
        binding.editName.setText(c.name)
        binding.editPhone.setText(c.phone)
        binding.editEmail.setText(c.email)
        binding.editCompany.setText(c.company)
        binding.editNotes.setText(c.notes)
    }

    private fun save() {
        val name = binding.editName.text.toString().trim()
        val phone = binding.editPhone.text.toString().trim()
        if (name.isEmpty() || phone.isEmpty()) {
            binding.editName.error = if (name.isEmpty()) "Wajib diisi" else null
            binding.editPhone.error = if (phone.isEmpty()) "Wajib diisi" else null
            return
        }

        val customer = Customer(
            id = currentCustomer?.id ?: 0,
            name = name, phone = phone,
            email = binding.editEmail.text.toString().trim(),
            company = binding.editCompany.text.toString().trim().ifEmpty { "-" },
            notes = binding.editNotes.text.toString().trim(),
            createdDate = currentCustomer?.createdDate ?: AppViewModel.today(),
            convertedFromLeadId = currentCustomer?.convertedFromLeadId
        )

        if (currentCustomer == null) viewModel.insertCustomer(customer) else viewModel.updateCustomer(customer)
        finish()
    }

    private fun delete() {
        currentCustomer?.let { viewModel.deleteCustomer(it); finish() }
    }
}
