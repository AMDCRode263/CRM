package com.crm.pro.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.crm.pro.databinding.FragmentDashboardBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.AppViewModel.Companion.formatRupiah
import com.crm.pro.ui.common.SimpleLine
import com.crm.pro.ui.common.SimpleLineAdapter
import kotlinx.coroutines.launch

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by viewModels({ requireActivity() })
    private lateinit var adapter: SimpleLineAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.cardLeads.statLabel.text = "Total Leads"
        binding.cardCustomers.statLabel.text = "Total Customers"
        binding.cardDeals.statLabel.text = "Active Deals"
        binding.cardRevenue.statLabel.text = "Revenue (Won)"

        adapter = SimpleLineAdapter(emptyList())
        binding.recyclerActivity.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerActivity.adapter = adapter

        refresh()

        viewModel.interactions.observe(viewLifecycleOwner) { list ->
            adapter.submit(list.take(10).map {
                SimpleLine(
                    title = "${it.relatedName} — ${it.type.name}",
                    subtitle = "${it.date}: ${it.note}"
                )
            })
        }

        // Re-load stats whenever underlying data changes
        viewModel.leads.observe(viewLifecycleOwner) { refresh() }
        viewModel.customers.observe(viewLifecycleOwner) { refresh() }
        viewModel.deals.observe(viewLifecycleOwner) { refresh() }
    }

    private fun refresh() {
        viewLifecycleOwner.lifecycleScope.launch {
            val stats = viewModel.loadDashboardStats()
            binding.cardLeads.statValue.text = stats.totalLeads.toString()
            binding.cardCustomers.statValue.text = stats.totalCustomers.toString()
            binding.cardDeals.statValue.text = stats.activeDeals.toString()
            binding.cardRevenue.statValue.text = formatRupiah(stats.revenue)
            binding.textConversion.text = "${stats.conversionRate}%"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
