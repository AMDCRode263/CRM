package com.crm.pro.ui.dashboard

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.crm.pro.R
import com.crm.pro.databinding.FragmentDashboardBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.AppViewModel.Companion.formatRupiah
import com.crm.pro.ui.common.SimpleLine
import com.crm.pro.ui.common.SimpleLineAdapter
import kotlinx.coroutines.launch

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by viewModels({ requireActivity() })
    private lateinit var activityAdapter: SimpleLineAdapter
    private lateinit var upcomingAdapter: SimpleLineAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        styleCard(binding.cardLeads, R.drawable.bg_card_blue, "Total Leads")
        styleCard(binding.cardCustomers, R.drawable.bg_card_pink, "Total Customers")
        styleCard(binding.cardDeals, R.drawable.bg_card_green, "Active Deals")
        styleCard(binding.cardConversion, R.drawable.bg_card_orange, "Conversion Rate")

        activityAdapter = SimpleLineAdapter(emptyList())
        binding.recyclerActivity.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerActivity.adapter = activityAdapter

        upcomingAdapter = SimpleLineAdapter(emptyList())
        binding.recyclerUpcoming.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerUpcoming.adapter = upcomingAdapter

        refresh()

        viewModel.interactions.observe(viewLifecycleOwner) { list ->
            activityAdapter.submit(list.take(8).map {
                SimpleLine(title = "${it.relatedName} — ${it.type.name}", subtitle = "${it.date}: ${it.note}")
            })
        }

        viewModel.tasks.observe(viewLifecycleOwner) { list ->
            upcomingAdapter.submit(
                list.filter { !it.done }.sortedBy { it.dueDate }.take(4).map {
                    SimpleLine(title = it.title, subtitle = "Due ${it.dueDate} • ${it.relatedName}")
                }
            )
        }

        viewModel.leads.observe(viewLifecycleOwner) { refresh() }
        viewModel.customers.observe(viewLifecycleOwner) { refresh() }
        viewModel.deals.observe(viewLifecycleOwner) { deals ->
            refresh()
            // Chart: jumlah deal dibuat per bulan (dari createdDate "yyyy-MM-dd")
            val counts = LinkedHashMap<String, Int>()
            deals.sortedBy { it.createdDate }.forEach { deal ->
                val month = deal.createdDate.take(7) // "yyyy-MM"
                counts[month] = (counts[month] ?: 0) + 1
            }
            val values = counts.values.map { it.toFloat() }
            val labels = counts.keys.map { it.takeLast(2) } // "MM"
            binding.lineChart.setData(values, labels)
        }
    }

    private fun styleCard(cardBinding: com.crm.pro.databinding.ItemStatCardBinding, gradientRes: Int, label: String) {
        cardBinding.cardInner.setBackgroundResource(gradientRes)
        cardBinding.statLabel.setTextColor(Color.WHITE)
        cardBinding.statValue.setTextColor(Color.WHITE)
        cardBinding.statLabel.text = label
    }

    private fun refresh() {
        viewLifecycleOwner.lifecycleScope.launch {
            val stats = viewModel.loadDashboardStats()
            binding.cardLeads.statValue.text = stats.totalLeads.toString()
            binding.cardCustomers.statValue.text = stats.totalCustomers.toString()
            binding.cardDeals.statValue.text = "${stats.activeDeals}\n${formatRupiah(stats.revenue)}"
            binding.cardConversion.statValue.text = "${stats.conversionRate}%"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
