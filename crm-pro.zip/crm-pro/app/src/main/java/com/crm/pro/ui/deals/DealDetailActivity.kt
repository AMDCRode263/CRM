package com.crm.pro.ui.deals

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.crm.pro.data.Customer
import com.crm.pro.data.Deal
import com.crm.pro.data.DealStage
import com.crm.pro.data.Product
import com.crm.pro.data.Quotation
import com.crm.pro.databinding.ActivityDealDetailBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.AppViewModel.Companion.formatRupiah
import com.crm.pro.ui.common.SimpleLine
import com.crm.pro.ui.common.SimpleLineAdapter
import kotlinx.coroutines.launch
import java.util.Calendar

class DealDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDealDetailBinding
    private val viewModel: AppViewModel by viewModels()
    private var currentDeal: Deal? = null
    private var dealId: Long = -1L

    private var customers: List<Customer> = emptyList()
    private var products: List<Product> = emptyList()
    private val stageOptions = DealStage.entries.toTypedArray()

    // quotation builder state: list of "Name x qty (subtotal)"
    private val quoteLines = mutableListOf<String>()
    private var quoteTotal = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDealDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.spinnerStage.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, stageOptions.map { it.name }))
        binding.editCloseDate.setOnClickListener { pickDate() }

        dealId = intent.getLongExtra("deal_id", -1L)

        viewModel.customers.observe(this) { list ->
            customers = list
            binding.spinnerCustomer.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, list.map { it.name }))
            currentDeal?.let { deal -> customers.firstOrNull { it.id == deal.customerId }?.let { binding.spinnerCustomer.setText(it.name, false) } }
        }

        viewModel.products.observe(this) { list ->
            products = list
            binding.spinnerProduct.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, list.map { it.name }))
        }

        if (dealId != -1L) {
            binding.title.text = "Detail Deal"
            binding.buttonDelete.visibility = android.view.View.VISIBLE
            binding.sectionQuotation.visibility = android.view.View.VISIBLE

            lifecycleScope.launch {
                currentDeal = viewModel.getDeal(dealId)
                currentDeal?.let { populate(it) }
            }

            val quotationsAdapter = SimpleLineAdapter(emptyList())
            binding.recyclerQuotations.layoutManager = LinearLayoutManager(this)
            binding.recyclerQuotations.adapter = quotationsAdapter
            viewModel.quotationsForDeal(dealId).observe(this) { list ->
                quotationsAdapter.submit(list.map {
                    SimpleLine(title = "${formatRupiah(it.total)} — ${it.createdDate}", subtitle = it.itemsSummary.replace("||", ", "))
                })
            }
        } else {
            binding.title.text = "Deal Baru"
        }

        binding.buttonAddQuoteItem.setOnClickListener { addQuoteItem() }
        binding.buttonSaveQuote.setOnClickListener { saveQuote() }
        binding.buttonSave.setOnClickListener { save() }
        binding.buttonDelete.setOnClickListener { delete() }
        updateQuoteDisplay()
    }

    private fun populate(d: Deal) {
        binding.editTitle.setText(d.title)
        binding.editValue.setText(d.value.toString())
        binding.editCloseDate.setText(d.expectedCloseDate)
        binding.editNotes.setText(d.notes)
        binding.spinnerStage.setText(d.stage.name, false)
        customers.firstOrNull { it.id == d.customerId }?.let { binding.spinnerCustomer.setText(it.name, false) }
    }

    private fun pickDate() {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, day ->
            binding.editCloseDate.setText(String.format("%04d-%02d-%02d", y, m + 1, day))
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun addQuoteItem() {
        val productName = binding.spinnerProduct.text.toString()
        val product = products.firstOrNull { it.name == productName }
        if (product == null) {
            Toast.makeText(this, "Pilih produk dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val qty = binding.editQty.text.toString().toIntOrNull() ?: 1
        val subtotal = product.price * qty
        quoteLines.add("${product.name} x$qty (${formatRupiah(subtotal)})")
        quoteTotal += subtotal
        updateQuoteDisplay()
    }

    private fun updateQuoteDisplay() {
        binding.textQuoteItems.text = if (quoteLines.isEmpty()) "Belum ada item." else quoteLines.joinToString("\n")
        binding.textQuoteTotal.text = "Total: ${formatRupiah(quoteTotal)}"
    }

    private fun saveQuote() {
        val deal = currentDeal
        if (deal == null) {
            Toast.makeText(this, "Simpan deal dulu sebelum buat penawaran", Toast.LENGTH_SHORT).show()
            return
        }
        if (quoteLines.isEmpty()) {
            Toast.makeText(this, "Tambahkan minimal 1 item", Toast.LENGTH_SHORT).show()
            return
        }
        viewModel.createQuotation(
            Quotation(
                dealId = deal.id, dealTitle = deal.title,
                itemsSummary = quoteLines.joinToString("||"),
                total = quoteTotal, createdDate = AppViewModel.today()
            )
        )
        Toast.makeText(this, "Penawaran disimpan", Toast.LENGTH_SHORT).show()
        quoteLines.clear()
        quoteTotal = 0.0
        updateQuoteDisplay()
    }

    private fun save() {
        val title = binding.editTitle.text.toString().trim()
        val customerName = binding.spinnerCustomer.text.toString()
        val customer = customers.firstOrNull { it.name == customerName }
        if (title.isEmpty() || customer == null) {
            if (title.isEmpty()) binding.editTitle.error = "Wajib diisi"
            if (customer == null) Toast.makeText(this, "Pilih customer", Toast.LENGTH_SHORT).show()
            return
        }
        val value = binding.editValue.text.toString().toDoubleOrNull() ?: 0.0
        val stage = stageOptions.firstOrNull { it.name == binding.spinnerStage.text.toString() } ?: DealStage.LEAD

        val deal = Deal(
            id = currentDeal?.id ?: 0,
            title = title, customerId = customer.id, value = value, stage = stage,
            expectedCloseDate = binding.editCloseDate.text.toString().trim(),
            notes = binding.editNotes.text.toString().trim(),
            createdDate = currentDeal?.createdDate ?: AppViewModel.today()
        )

        if (currentDeal == null) viewModel.insertDeal(deal) else viewModel.updateDeal(deal)
        finish()
    }

    private fun delete() {
        currentDeal?.let { viewModel.deleteDeal(it); finish() }
    }
}
