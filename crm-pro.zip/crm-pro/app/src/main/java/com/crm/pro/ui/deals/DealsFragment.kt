package com.crm.pro.ui.deals

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.crm.pro.data.DealStage
import com.crm.pro.databinding.FragmentPipelineBinding
import com.crm.pro.databinding.ItemStageSectionBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.AppViewModel.Companion.formatRupiah
import com.crm.pro.ui.common.SimpleLine
import com.crm.pro.ui.common.SimpleLineAdapter

class DealsFragment : Fragment() {

    private var _binding: FragmentPipelineBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by viewModels({ requireActivity() })

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentPipelineBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.deals.observe(viewLifecycleOwner) { allDeals ->
            binding.stageContainer.removeAllViews()
            DealStage.entries.forEach { stage ->
                val dealsInStage = allDeals.filter { it.stage == stage }
                if (dealsInStage.isEmpty()) return@forEach

                val sectionBinding = ItemStageSectionBinding.inflate(
                    LayoutInflater.from(requireContext()), binding.stageContainer, false
                )
                val total = dealsInStage.sumOf { it.value }
                sectionBinding.stageHeader.text = "${stage.name} (${dealsInStage.size}) — ${formatRupiah(total)}"

                val adapter = SimpleLineAdapter(dealsInStage.map { deal ->
                    SimpleLine(
                        title = deal.title,
                        subtitle = "${formatRupiah(deal.value)} • target: ${deal.expectedCloseDate}",
                        onClick = {
                            val intent = Intent(requireContext(), DealDetailActivity::class.java)
                            intent.putExtra("deal_id", deal.id)
                            startActivity(intent)
                        }
                    )
                })
                sectionBinding.stageRecycler.layoutManager = LinearLayoutManager(requireContext())
                sectionBinding.stageRecycler.adapter = adapter

                binding.stageContainer.addView(sectionBinding.root)
            }
        }

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(requireContext(), DealDetailActivity::class.java))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
