package com.crm.pro.ui.leads

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.crm.pro.data.Lead
import com.crm.pro.data.LeadSource
import com.crm.pro.data.LeadStatus
import com.crm.pro.databinding.ActivityLeadDetailBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.customers.CustomerDetailActivity
import kotlinx.coroutines.launch

class LeadDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLeadDetailBinding
    private val viewModel: AppViewModel by viewModels()
    private var currentLead: Lead? = null
    private var leadId: Long = -1L

    private val sourceOptions = LeadSource.entries.toTypedArray()
    private val statusOptions = LeadStatus.entries.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLeadDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.spinnerSource.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, sourceOptions.map { it.name }))
        binding.spinnerStatus.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, statusOptions.map { it.name }))

        leadId = intent.getLongExtra("lead_id", -1L)

        if (leadId != -1L) {
            binding.title.text = "Detail Lead"
            binding.buttonDelete.visibility = android.view.View.VISIBLE
            lifecycleScope.launch {
                currentLead = viewModel.getLead(leadId)
                currentLead?.let { populate(it) }
            }
        } else {
            binding.title.text = "Lead Baru"
            binding.editScore.setText("50")
        }

        binding.buttonSave.setOnClickListener { save() }
        binding.buttonConvert.setOnClickListener { convert() }
        binding.buttonDelete.setOnClickListener { delete() }
    }

    private fun populate(l: Lead) {
        binding.editName.setText(l.name)
        binding.editPhone.setText(l.phone)
        binding.editEmail.setText(l.email)
        binding.editScore.setText(l.score.toString())
        binding.editNotes.setText(l.notes)
        binding.spinnerSource.setText(l.source.name, false)
        binding.spinnerStatus.setText(l.status.name, false)
        if (l.status != LeadStatus.CONVERTED) {
            binding.buttonConvert.visibility = android.view.View.VISIBLE
        }
    }

    private fun save() {
        val name = binding.editName.text.toString().trim()
        val phone = binding.editPhone.text.toString().trim()
        if (name.isEmpty() || phone.isEmpty()) {
            binding.editName.error = if (name.isEmpty()) "Wajib diisi" else null
            binding.editPhone.error = if (phone.isEmpty()) "Wajib diisi" else null
            return
        }
        val source = sourceOptions.firstOrNull { it.name == binding.spinnerSource.text.toString() } ?: LeadSource.LAINNYA
        val status = statusOptions.firstOrNull { it.name == binding.spinnerStatus.text.toString() } ?: LeadStatus.NEW
        val score = binding.editScore.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 50

        val lead = Lead(
            id = currentLead?.id ?: 0,
            name = name, phone = phone,
            email = binding.editEmail.text.toString().trim(),
            source = source, status = status, score = score,
            notes = binding.editNotes.text.toString().trim(),
            createdDate = currentLead?.createdDate ?: AppViewModel.today()
        )

        if (currentLead == null) viewModel.insertLead(lead) else viewModel.updateLead(lead)
        finish()
    }

    private fun convert() {
        val lead = currentLead ?: run {
            Toast.makeText(this, "Simpan lead dulu sebelum konversi", Toast.LENGTH_SHORT).show()
            return
        }
        viewModel.convertLeadToCustomer(lead) { newCustomerId ->
            Toast.makeText(this, "${lead.name} dikonversi jadi Customer", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, CustomerDetailActivity::class.java)
            intent.putExtra("customer_id", newCustomerId)
            startActivity(intent)
            finish()
        }
    }

    private fun delete() {
        currentLead?.let { viewModel.deleteLead(it); finish() }
    }
}
