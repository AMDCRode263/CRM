package com.crm.pro.ui.products

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.crm.pro.data.Product
import com.crm.pro.databinding.ActivityProductDetailBinding
import com.crm.pro.ui.AppViewModel
import kotlinx.coroutines.launch

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProductDetailBinding
    private val viewModel: AppViewModel by viewModels()
    private var currentProduct: Product? = null
    private var productId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        productId = intent.getLongExtra("product_id", -1L)

        if (productId != -1L) {
            binding.title.text = "Detail Produk"
            binding.buttonDelete.visibility = android.view.View.VISIBLE
            lifecycleScope.launch {
                currentProduct = viewModel.getProduct(productId)
                currentProduct?.let {
                    binding.editName.setText(it.name)
                    binding.editPrice.setText(it.price.toString())
                    binding.editDescription.setText(it.description)
                }
            }
        } else {
            binding.title.text = "Produk Baru"
        }

        binding.buttonSave.setOnClickListener { save() }
        binding.buttonDelete.setOnClickListener { delete() }
    }

    private fun save() {
        val name = binding.editName.text.toString().trim()
        if (name.isEmpty()) {
            binding.editName.error = "Wajib diisi"
            return
        }
        val price = binding.editPrice.text.toString().toDoubleOrNull() ?: 0.0
        val product = Product(
            id = currentProduct?.id ?: 0,
            name = name, price = price,
            description = binding.editDescription.text.toString().trim()
        )
        if (currentProduct == null) viewModel.insertProduct(product) else viewModel.updateProduct(product)
        finish()
    }

    private fun delete() {
        currentProduct?.let { viewModel.deleteProduct(it); finish() }
    }
}
