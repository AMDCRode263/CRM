package com.crm.pro.ui.reports

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.crm.pro.data.DealStage
import com.crm.pro.data.LeadSource
import com.crm.pro.databinding.FragmentListBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.AppViewModel.Companion.formatRupiah
import com.crm.pro.ui.common.SimpleLine
import com.crm.pro.ui.common.SimpleLineAdapter

class ReportsFragment : Fragment() {

    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by viewModels({ requireActivity() })
    private lateinit var adapter: SimpleLineAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = SimpleLineAdapter(emptyList())
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        viewModel.deals.observe(viewLifecycleOwner) { refresh() }
        viewModel.leads.observe(viewLifecycleOwner) { refresh() }
    }

    private fun refresh() {
        val deals = viewModel.deals.value ?: emptyList()
        val leads = viewModel.leads.value ?: emptyList()
        val lines = mutableListOf<SimpleLine>()

        val totalRevenue = deals.filter { it.stage == DealStage.WON }.sumOf { it.value }
        val totalDeals = deals.size
        val won = deals.count { it.stage == DealStage.WON }
        val lost = deals.count { it.stage == DealStage.LOST }
        val conversion = if (totalDeals > 0) won * 100 / totalDeals else 0

        lines.add(SimpleLine("Total Revenue (Won Deals)", formatRupiah(totalRevenue)))
        lines.add(SimpleLine("Conversion Rate", "$conversion% ($won menang dari $totalDeals deal)"))
        lines.add(SimpleLine("Deal Lost", "$lost deal"))

        lines.add(SimpleLine("— Revenue per Stage —", ""))
        DealStage.entries.forEach { stage ->
            val stageDeals = deals.filter { it.stage == stage }
            if (stageDeals.isNotEmpty()) {
                lines.add(SimpleLine(stage.name, "${stageDeals.size} deal • ${formatRupiah(stageDeals.sumOf { it.value })}"))
            }
        }

        lines.add(SimpleLine("— Leads per Sumber —", ""))
        LeadSource.entries.forEach { source ->
            val count = leads.count { it.source == source }
            if (count > 0) lines.add(SimpleLine(source.name, "$count lead"))
        }

        binding.emptyView.visibility = View.GONE
        adapter.submit(lines)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
