package com.crm.pro.ui.tasks

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.crm.pro.data.Customer
import com.crm.pro.data.Lead
import com.crm.pro.data.RelatedType
import com.crm.pro.data.Task
import com.crm.pro.databinding.ActivityTaskDetailBinding
import com.crm.pro.ui.AppViewModel
import kotlinx.coroutines.launch
import java.util.Calendar

class TaskDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTaskDetailBinding
    private val viewModel: AppViewModel by viewModels()
    private var currentTask: Task? = null
    private var taskId: Long = -1L

    private var customers: List<Customer> = emptyList()
    private var leads: List<Lead> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTaskDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.editDueDate.setOnClickListener { pickDate() }

        taskId = intent.getLongExtra("task_id", -1L)

        viewModel.customers.observe(this) { customers = it; refreshRelatedOptions() }
        viewModel.leads.observe(this) { leads = it; refreshRelatedOptions() }

        if (taskId != -1L) {
            binding.title.text = "Detail Tugas"
            binding.buttonDelete.visibility = android.view.View.VISIBLE
            lifecycleScope.launch {
                currentTask = viewModel.getTask(taskId)
                currentTask?.let { populate(it) }
            }
        } else {
            binding.title.text = "Tugas Baru"
            binding.editDueDate.setText(AppViewModel.today())
        }

        binding.buttonSave.setOnClickListener { save() }
        binding.buttonDelete.setOnClickListener { delete() }
    }

    private fun refreshRelatedOptions() {
        val options = mutableListOf("(Tidak ada)")
        options += customers.map { "Customer: ${it.name}" }
        options += leads.map { "Lead: ${it.name}" }
        binding.spinnerRelated.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, options))
    }

    private fun populate(t: Task) {
        binding.editTitle.setText(t.title)
        binding.editDueDate.setText(t.dueDate)
        binding.editNotes.setText(t.notes)
        binding.checkDone.isChecked = t.done
        if (t.relatedType != null) {
            val prefix = if (t.relatedType == RelatedType.CUSTOMER) "Customer" else "Lead"
            binding.spinnerRelated.setText("$prefix: ${t.relatedName}", false)
        }
    }

    private fun pickDate() {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            binding.editDueDate.setText(String.format("%04d-%02d-%02d", y, m + 1, d))
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun save() {
        val title = binding.editTitle.text.toString().trim()
        if (title.isEmpty()) {
            binding.editTitle.error = "Wajib diisi"
            return
        }

        val relatedText = binding.spinnerRelated.text.toString()
        var relatedType: RelatedType? = null
        var relatedId: Long? = null
        var relatedName = ""

        if (relatedText.startsWith("Customer: ")) {
            val name = relatedText.removePrefix("Customer: ")
            customers.firstOrNull { it.name == name }?.let {
                relatedType = RelatedType.CUSTOMER; relatedId = it.id; relatedName = it.name
            }
        } else if (relatedText.startsWith("Lead: ")) {
            val name = relatedText.removePrefix("Lead: ")
            leads.firstOrNull { it.name == name }?.let {
                relatedType = RelatedType.LEAD; relatedId = it.id; relatedName = it.name
            }
        }

        val task = Task(
            id = currentTask?.id ?: 0,
            title = title, relatedType = relatedType, relatedId = relatedId, relatedName = relatedName,
            dueDate = binding.editDueDate.text.toString().trim(),
            done = binding.checkDone.isChecked,
            notes = binding.editNotes.text.toString().trim()
        )

        if (currentTask == null) viewModel.insertTask(task) else viewModel.updateTask(task)
        finish()
    }

    private fun delete() {
        currentTask?.let { viewModel.deleteTask(it); finish() }
    }
}
