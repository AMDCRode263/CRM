package com.crm.pro.ui.tasks

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.crm.pro.databinding.FragmentListWithFabBinding
import com.crm.pro.ui.AppViewModel
import com.crm.pro.ui.common.SimpleLine
import com.crm.pro.ui.common.SimpleLineAdapter

class TasksFragment : Fragment() {

    private var _binding: FragmentListWithFabBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by viewModels({ requireActivity() })
    private lateinit var adapter: SimpleLineAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentListWithFabBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = SimpleLineAdapter(emptyList())
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerView.adapter = adapter

        viewModel.tasks.observe(viewLifecycleOwner) { list ->
            binding.emptyView.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            adapter.submit(list.map { task ->
                val statusMark = if (task.done) "✅ Selesai" else "⏳ Due: ${task.dueDate}"
                SimpleLine(
                    title = task.title,
                    subtitle = "$statusMark • ${task.relatedName}",
                    onClick = {
                        val intent = Intent(requireContext(), TaskDetailActivity::class.java)
                        intent.putExtra("task_id", task.id)
                        startActivity(intent)
                    }
                )
            })
        }

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(requireContext(), TaskDetailActivity::class.java))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
